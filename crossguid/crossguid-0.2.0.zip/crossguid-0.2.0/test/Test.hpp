#pragma once

#include "../Guid.hpp"
#include <iostream>

int test(std::ostream &outStream);
