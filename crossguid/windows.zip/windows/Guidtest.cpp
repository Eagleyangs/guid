﻿#include <iostream>
#include "Guid.hpp"

#ifdef WIN32
#ifdef _DEBUG
#pragma comment(lib, "xgd.lib")
#else
#pragma comment(lib, "xg.lib")
#endif
#endif //WIN32

int main()
{
    std::cout << "Hello World!\n" << std::endl;
	std::cout << xg::newGuid() << std::endl;
	return 0;
}
