#include <iostream>
#include "Guid.hpp"

int main()
{
    std::cout << "Hello World!\n" << std::endl;
    std::cout << xg::newGuid() << std::endl;
    return 0;
}
